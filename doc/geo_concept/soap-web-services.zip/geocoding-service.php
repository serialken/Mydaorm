<h1>Geocoding service</h1>

<?php
// Display all errors:
error_reporting(E_ALL);
ini_set('display_errors', '1');

///////////////////////////////////////////////////////////////////////
///////////////////////////  CREATE REQUEST ///////////////////////////
///////////////////////////////////////////////////////////////////////

class AddressType{

   function __construct($CountryCode,$City,$PostalCode,$AddressLine,$Projection="MAP")  {   
     $this->CountryCode=$CountryCode;
     $this->City=$City;
     $this->PostalCode=$PostalCode;
     $this->AddressLine=$AddressLine;
     $this->Address=$AddressLine;
     $this->Projection=$Projection;     
   }
};


$addressType=new AddressType("fr","Paris","75013","25 rue de Toldiac","WGS84");
$request=array(
  "GeocodeRequest" => array("Address" => $addressType)
);

///////////////////////////////////////////////////////////////////////
/////////////////////////////  CALL SOAP  /////////////////////////////
///////////////////////////////////////////////////////////////////////

try{
  $clientOptions=array(
    'trace'=>true,
    'exceptions'=>true,
    'encoding'=>'utf-8'
  );
  
  $client = new SoapClient('http://geoweb.geoconcept.com/geoweb2/ws/GeocodeService/geocode.wsdl', $clientOptions);
  
  $response = $client->__soapCall("Geocode",$request);   
 
  echo "<h2>Request</h2>";
  echo "<pre>";
  var_dump($request);
  echo "</pre>";
 
  echo "<h2>Response (InitialAddress)</h2>";
  echo "<pre>";
  var_dump($response->InitialAddress);
  echo "</pre>";
  
  echo "<h2>Response (GeocodedAddress)</h2>";
  echo "<pre>";
  var_dump($response->GeocodedAddress);
  echo "</pre>";
} 
catch (SoapFault $e) {
  echo $e; 
}
?>