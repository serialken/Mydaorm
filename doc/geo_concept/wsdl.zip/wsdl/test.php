<?php
// On rapporte toutes les erreurs:
error_reporting(E_ALL);

// nusoap librairie:
require_once('nusoap/lib/nusoap.php');

// Instantiation de nusoap_client:
$client = new nusoap_client(
        'http://geoweb.geoconcept.com/geoweb2/ws/RouteService/route.wsdl', 'wsdl');

// On teste s'il y a des erreurs lors de l'instantiation du client:
$err = $client->getError();
if ($err)
{ // Affichage des erreurs:
echo '<h2>Constructor error</h2><pre>' . $err . '</pre>';
}

// On d�finit les options:
$route_options=array
(
   'Method'=>'TIME',
'Projection'=>'MAP',
);

// On d�finit la premi�re coordonn�e:
$step1 = array
(
"X"=>602725,
"Y"=>2425604,
"Address" => "25 rue de Tolbiac",
"City"     => "Paris",
);

// On d�finit la seconde coordonn�e:
$step2 =array
(
"X"=>599266,
"Y"=>2425096,
);

// On d�tinit la route step:
$route_steps=array
(
   $step1,
$step2,
);

// Le param�tre � soumettre � nusoap:
$myparam=array
(
"RouteRequest" => array
(
"Options" => $route_options,
"Step"=> $route_steps,
)
);

$result = $client->call('Route',$myparam); // Calls the method


// Check for a fault
if ($client->fault) {
echo '<h2>Fault</h2><pre>';
print_r($result);
echo '</pre>';
} else {
// Check for errors
$err = $client->getError();
if ($err) {
// Display the error
echo '<h2>Error</h2><pre>' . $err . '</pre>';
} else {
// Display the result
echo '<h2>Result</h2><pre>';
print_r($result);
echo '</pre>';
}
}

echo '<h2>Request</h2><pre>' . htmlspecialchars($client->request, ENT_QUOTES) . '</pre>';
echo '<h2>Response</h2><pre>' . htmlspecialchars($client->response, ENT_QUOTES) . '</pre>';
echo '<h2>Debug</h2><pre>' . htmlspecialchars($client->debug_str, ENT_QUOTES) . '</pre>';
?>