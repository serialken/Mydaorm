<h1>Route service</h1>

<?php
// Display all errors:
error_reporting(E_ALL);
ini_set('display_errors', '1');

///////////////////////////////////////////////////////////////////////
///////////////////////////  CREATE REQUEST ///////////////////////////
///////////////////////////////////////////////////////////////////////

class RouteOptions {
  
  function __construct($Method,$Projection,$Format,$Exclusions=array())  {
    $this->Method=$Method;
    $this->Projection=$Projection;
    $this->Format=$Format;
    $this->Exclusions=$Exclusions;
  }

}

class RoutePointType {
 
  function __construct($X,$Y,$Address,$City)  {
    $this->X=$X;
    $this->Y=$Y;
    $this->Address=$Address;
    $this->City=$City;
  }
}


$routeoptions=new RouteOptions("TIME","MAP","STANDARD",array("Toll"));
$step1=new RoutePointType("602725","2425604","25 rue de Tolbiac","Paris");
$step2=new RoutePointType("794045","2088583","","Lyon");

$request=array(
  "SearchAroundRequest" => array(
     "Options" => $routeoptions,     
     "Step" => array($step1,$step2)     
    )
);

///////////////////////////////////////////////////////////////////////
/////////////////////////////  CALL SOAP  /////////////////////////////
///////////////////////////////////////////////////////////////////////

try{
  $clientOptions=array(
    'trace'=>true,
    'exceptions'=>true,
    'encoding'=>'utf-8'
  );
  
  $client = new SoapClient('http://geoweb.geoconcept.com/geoweb2/ws/RouteService/route.wsdl', $clientOptions);
  
  $response = $client->__soapCall("Route",$request);   
 
  echo "<h2>Request</h2>";
  echo "<pre>";
  var_dump($request);
  echo "</pre>";
 
  echo "<h2>Response</h2>";
  echo "<pre>";
  var_dump($response);  
  echo "</pre>"; 
} 
catch (SoapFault $e) {
  echo $e; 
}
?>