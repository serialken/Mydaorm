<h1>SearchAround service</h1>

<?php
// Display all errors:
error_reporting(E_ALL);
ini_set('display_errors', '1');

///////////////////////////////////////////////////////////////////////
///////////////////////////  CREATE REQUEST ///////////////////////////
///////////////////////////////////////////////////////////////////////

class SearchAroundOptions {
  
  function __construct($SearchMethod,$Projection,$Exclusions=array())  {
    $this->SearchMethod=$SearchMethod;
    $this->Projection=$Projection;
    $this->Exclusions=$Exclusions;
  }

}

class SearchAroundPointType {
 
  function __construct($X,$Y,$Id="",$Priority1="",$Priority2="")  {
    $this->X=$X;
    $this->Y=$Y;
    $this->Id=$Id;
    $this->Priority1=$Priority1;
    $this->Priority2=$Priority2;
  }
}


$searcharoundoptions=new SearchAroundOptions("TIME","MAP");
$target=new SearchAroundPointType("602725","2425604");
$resource1=new SearchAroundPointType("599266","2425096","2","1","1");
$resource2=new SearchAroundPointType("599266","2425096","3","1","2");
$resource3=new SearchAroundPointType("599266","2425096","4","1","1");

$request=array(
  "SearchAroundRequest" => array(
     "Options" => $searcharoundoptions,
     "Target" => $target,
     "Resource" => array($resource1,$resource2,$resource3)     
    )
);

///////////////////////////////////////////////////////////////////////
/////////////////////////////  CALL SOAP  /////////////////////////////
///////////////////////////////////////////////////////////////////////

try{
  $clientOptions=array(
    'trace'=>true,
    'exceptions'=>true,
    'encoding'=>'utf-8'
  );
  
  $client = new SoapClient('http://geoweb.geoconcept.com/geoweb2/ws/SearchAroundService/searchAround.wsdl', $clientOptions);
  
  $response = $client->__soapCall("SearchAround",$request);   
 
  echo "<h2>Request</h2>";
  echo "<pre>";
  var_dump($request);
  echo "</pre>";
 
  echo "<h2>Response</h2>";
  echo "<pre>";
  var_dump($response);  
  echo "</pre>"; 
} 
catch (SoapFault $e) {
  echo $e; 
}
?>